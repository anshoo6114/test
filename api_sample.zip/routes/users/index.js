var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/:userId', getUserById = async (req, res) => {
  res.send('respond with a resource with id: ' + req.params.userId);
});

router.post('/', function(req, res, next) {
    res.send('Received a POST request');
});

module.exports = router;
